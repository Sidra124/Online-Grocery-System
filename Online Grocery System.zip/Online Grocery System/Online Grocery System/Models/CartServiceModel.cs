﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace Online_Grocery_System.Models
{
    class CartServiceModel
    {
        ObservableCollection<Product> Products;

        public CartServiceModel()
        {

        }


        public bool AddinCart(int id, int quantity , Cart c)
        {
            string conString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=mynewDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False ";
            SqlConnection con = new SqlConnection(conString);

            con.Open();
            string query = $"select * from Products";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            int insertedRows = cmd.ExecuteNonQuery();

            while (dr.Read())
            {
                if ( id== c.CartID && quantity == c.CartQuantity)
                   

                con.Close();
                return true;

            }
            con.Close();
            return false;

        }


        public ObservableCollection<Product> ReadValuesfromProducts()  // to take data from Products table
        {
            ObservableCollection<Product> list = new ObservableCollection<Product>();

            string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=mynewDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False ";
            SqlConnection con = new SqlConnection(connString);
            con.Open();
            string query = "Select * from Products";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Product p = new Product();
                p.ID = System.Convert.ToInt32(dr[0]);
                p.Name = System.Convert.ToString(dr[1]);
                p.Price = System.Convert.ToInt32(dr[2]);
                p.Quantity = System.Convert.ToInt32(dr[3]);

                list.Add(p);

            }

            con.Close();

            return list;

        }

    }
}
