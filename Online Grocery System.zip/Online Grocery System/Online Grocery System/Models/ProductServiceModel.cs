﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Data.SqlClient;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows;

namespace Online_Grocery_System.Models
{
    class ProductServiceModel
    {

        ObservableCollection<Product> Products;


        public ProductServiceModel()
        { }
            
        
        public void Addpro(Product A)
        {
            string conString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=mynewDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False ";
            SqlConnection connection = new SqlConnection(conString);
          
                
                string query = $"insert into Products(ProductID, ProductName, Price, Quantity) values('{A.ID}', '{A.Name}', '{A.Price}', '{A.Quantity}')";
                SqlCommand cmd = new SqlCommand(query, connection);
                connection.Open();
                int insertedRows = cmd.ExecuteNonQuery();

                connection.Close();
            
           
        }

        public void Remove(int ID)
        {
            string conString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=mynewDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False ";
            SqlConnection connection = new SqlConnection(conString);
            string query = $"delete from Products where ProductID='{ID}'" ;
         
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            int insertedRows = cmd.ExecuteNonQuery();
            if(insertedRows>0)
            {
               MessageBox.Show("Row Deleted!");
            }

            connection.Close();
        }



        public ObservableCollection<Product> ReadValuesfromProducts()  // to take data from Products table
        {
            ObservableCollection<Product> list=new ObservableCollection<Product> ();

            string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=mynewDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False ";
            SqlConnection con = new SqlConnection(connString);
            con.Open();
            string query = "Select * from Products";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Product p = new Product();
                p.ID = System.Convert.ToInt32(dr[0]);
                p.Name =System.Convert.ToString( dr[1]);
                p.Price =System.Convert.ToInt32( dr[2]);
                p.Quantity =System.Convert.ToInt32( dr[3]);

                list.Add(p);
               
            }

            con.Close();

            return list;

        }

        //public ObservableCollection<Product> GetAllStudents()
        // {
        // return;

        //}
    }
}

