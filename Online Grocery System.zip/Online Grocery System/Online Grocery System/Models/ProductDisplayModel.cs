﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using Microsoft.Data.SqlClient;
//using System.ComponentModel;
//using System.Collections.ObjectModel;

//namespace Online_Grocery_System.Models
//{
//    class ProductDisplayModel: INotifyPropertyChanged
//    {
//        public event PropertyChangedEventHandler PropertyChanged;

//        public void ReadValuesfromProducts()  // to take data from Products table
//        {

//            string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=mynewDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False ";
//            SqlConnection con = new SqlConnection(connString);
//            con.Open();
//            string query = "Select * from Products";
//            SqlCommand cmd = new SqlCommand(query, con);
//            SqlDataReader dr = cmd.ExecuteReader();
//            while (dr.Read())
//            {
//                Console.WriteLine($"ID : {dr.GetValue(0)}, Name : {dr.GetValue(1)}, Price : {dr.GetValue(2)}, Quantity : {dr.GetValue(3)} ");
//            }

//            con.Close();

//        }
//    }
//}
