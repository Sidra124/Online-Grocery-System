﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Online_Grocery_System.Models
{
    class Cart : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propName)
        {

            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }


        private int cartID;

        public int CartID
        {
            get { return cartID; }
            set { cartID = value; OnPropertyChanged("ID"); }
        }

        private string cartName;

        public string CartName
        {
            get { return cartName; }
            set { cartName = value; OnPropertyChanged("Name"); }
        }

        private int cartQuantity;

        public int CartQuantity
        {
            get { return cartQuantity; }
            set { cartQuantity = value; OnPropertyChanged("Quantity"); }
        }


        private float cartPrice;

        public float CartPrice
        {
            get { return cartPrice; }
            set { cartPrice = value; OnPropertyChanged("Price"); }
        }

    }
}
















