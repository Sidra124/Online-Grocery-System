﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Microsoft.Data.SqlClient;

namespace Online_Grocery_System.Models
{
    class CustomerServiceModel
    {

        public CustomerServiceModel()
        {
            
        }

        public void SignUpCustomer(CustomerModel C)
        {
            string conString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=mynewDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False ";
            SqlConnection connection = new SqlConnection(conString);


            string query = $"insert into Customers(Username, Password, PhoneNo) values('{C.UserName}', '{C.PassWord}', '{C.PhoneNo}')";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            int insertedRows = cmd.ExecuteNonQuery();

            connection.Close();

        }


        public bool LoginCustomer(string username, string password, CustomerModel c)
        {
            string conString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=mynewDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False ";
            SqlConnection con = new SqlConnection(conString);

            con.Open();
            string query = $"select * from Customer";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            int insertedRows = cmd.ExecuteNonQuery();

            while(dr.Read())
            {
                if (username == c.Username && password == c.Password)
                    con.Close();
                return true;
               
            }
            con.Close();
            return false;

        }
     

        internal object GetAllCustomers()
        {
            throw new NotImplementedException();
        }
    }
}
