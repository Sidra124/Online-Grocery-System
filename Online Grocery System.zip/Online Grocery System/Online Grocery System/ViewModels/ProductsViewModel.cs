﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using Online_Grocery_System.Models;
using Online_Grocery_System.Commands;
using System.Collections.ObjectModel;

namespace Online_Grocery_System.ViewModels
{
    class ProductsViewModel: BaseViewModel
    {

         public ObservableCollection<Product> array1 { get; set; }


        public ProductsViewModel()
        {
            ProductServiceModel p = new ProductServiceModel();
            array1 = p.ReadValuesfromProducts();

            CartServiceModel c = new CartServiceModel();
            array1 = c.ReadValuesfromProducts();

        }


        //    public string UserName { get; set; }
        //    public string Password { get; set; }
        //    public string Phone { get; set; }

        //    public DelegateCommand AddCommand { get; set; }

        //  //  ProductAddModel pAdd;
        //    public ProductsViewModel()
        //    {
        //       // pAdd = new ProductAddModel();

        //       // Students = studentService.GetAllStudents();
        //        AddCommand = new DelegateCommand(Add, canAdd);
        //    }

        //    public void Add(object o)
        //    {
        //        ProductS p = new ProductS();
        //        p.Username = this.UserName;
        //        p.Password = this.Password;
        //        p.Phone = this.Phone;
        //       // pAdd.AddProducts(p);
        //    }
        //    public bool 
        //        canAdd(object o)
        //    {

        //        if (string.IsNullOrEmpty(UserName.ToString()) ||
        //           string.IsNullOrEmpty(Password) ||
        //           string.IsNullOrEmpty(Phone.ToString()))
        //        {
        //            return false;
        //        }
        //        else
        //        {
        //            return true;
        //        }

        //    }
    }
}

