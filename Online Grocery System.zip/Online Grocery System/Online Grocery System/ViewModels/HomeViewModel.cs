﻿using Online_Grocery_System.Commands;
using System;
using System.Collections.Generic;
using System.Text;


namespace Online_Grocery_System.ViewModels
{
    class HomeViewModel: BaseViewModel
    {

        public DelegateCommand AdminCommand { get; set; }
        public DelegateCommand CustomerCommand { get; set; }


        public HomeViewModel()
        {
            AdminCommand = new DelegateCommand(Admin, canAdmin);
            CustomerCommand = new DelegateCommand(Customer, canCustomer);
        }


        public void Admin(object o)
        {
            SelectedViewModel = new AdminViewModel();
        }


        public bool canAdmin(object o)
        {
            return true;
        }


        public void Customer(object o)
        {
            SelectedViewModel = new CustomerViewModel();
        }


        public bool canCustomer(object o)
        {
            return true;
        }
    }
}
