﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Online_Grocery_System.Models;
using Online_Grocery_System.Commands;
using System.Windows.Controls;

namespace Online_Grocery_System.ViewModels
{
    class CustomerViewModel: BaseViewModel
    { 

        public CustomerModel SelectedCustomer { get; set; }
        public string UserName { get => userName; set { userName = value; OnPropertyChanged("UserName"); } }
        public string Username { get => username; set { username = value; OnPropertyChanged("Username"); } }
        public string PassWord { get => passWord; set { passWord = value; OnPropertyChanged("PassWord"); } }
        public string Password { get => password; set { password = value; OnPropertyChanged("Password"); } }

        public string PhoneNo { get => phoneNo; set { phoneNo = value; OnPropertyChanged("Phone NO"); } }
        //public ObservableCollection<Student> Students { get; set; }
        public DelegateCommand LoginCommand { get; set; }
        public DelegateCommand SignUpCommand { get; set; }
      

        CustomerServiceModel Cservice;
        private string userName;
        private string username;
        private string passWord;
        private string password;
        private string phoneNo;

        public CustomerViewModel()
        {
            Cservice = new CustomerServiceModel();

           // Students = studentService.GetAllStudents();
            LoginCommand = new DelegateCommand(Login, canLogin);
            SignUpCommand = new DelegateCommand(SignUp, canSignUp);
            
        }

        public void SignUp(object o)
        {

            string passWord = (o as PasswordBox).Password;
            CustomerModel C = new CustomerModel();
            C.UserName = this.UserName;
            C.PassWord = this.PassWord;
            C.PhoneNo = this.PhoneNo;
            //studentService.AddStudent(s);
        }

  
        public bool canSignUp(object o)
        {

            return true;

        }


        public void Login(object o)
        {

            SelectedViewModel = new CartViewModel();
            string password = (o as PasswordBox).Password;
            CustomerModel C = new CustomerModel();
            C.Username = this.Username;
            C.Password = this.Password;
           
            //studentService.AddStudent(s);
        }


        public bool canLogin(object o)
        {

            return true;

        }
    }
}



    
