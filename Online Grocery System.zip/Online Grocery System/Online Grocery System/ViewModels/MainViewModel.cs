﻿using Online_Grocery_System.Commands;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;

namespace Online_Grocery_System.ViewModels
{
    class MainViewModel:BaseViewModel
    {
       

       // public ICommand UpdateViewCommand { get; set; }
        public MainViewModel()
        {

            SelectedViewModel = new HomeViewModel();
           // UpdateViewCommand = new DelegateCommand(ViewSelector, canExecute);
           
            //SelectedViewModel = new ProductsViewModel();
            //SelectedViewModel = new AdminViewModel();

        }

        //bool canExecute(object o)
        //{
        //    return true;
        //}

        //void ViewSelector(object o)
        //{
            
        //    if ((o as string).Equals("Admin"))
        //    {
        //        SelectedViewModel = new AdminViewModel();
        //    }
        //    else if ((o as string).Equals("Customer"))
        //    {
        //       // SelectedViewModel = new CustomerViewModel();
        //    }
           
        //}
    }
}

    