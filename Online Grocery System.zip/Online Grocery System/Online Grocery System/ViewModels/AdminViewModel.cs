﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Online_Grocery_System.Models;
using Online_Grocery_System.Commands;

namespace Online_Grocery_System.ViewModels
{
    class AdminViewModel:BaseViewModel
    { 

       // public AdminModel SelectedAdmin { get; set; }
        public int ID { get => iD; set { iD = value; OnPropertyChanged("ID"); } }
        public int delID { get => deliD; set { deliD = value; OnPropertyChanged("delID"); } }
        public string Name { get => name; set { name = value; OnPropertyChanged("Name"); } }
        public int Price { get => price; set { price = value; OnPropertyChanged("Price"); } }
        public int Quantity { get => quantity; set { quantity = value; OnPropertyChanged("Quantity"); } }
        public ObservableCollection<ProductS> Students { get; set; }
        public DelegateCommand AddCommand { get; set; }
        public DelegateCommand RemoveCommand { get; set; }
        public DelegateCommand SearchCommand { get; set; }
        public DelegateCommand LogoutCommand { get; set; }
        public DelegateCommand ProductCommand { get; set; }

        ProductServiceModel ProductService { get; set; }
        private string name;
        private int quantity;
        private int iD;
        private int deliD;
        private int price;

        public AdminViewModel()
        {
            // studentService = new StudentService();

            // Students = studentService.GetAllStudents();

            ProductService = new ProductServiceModel();
            AddCommand = new DelegateCommand(Add, canAdd);
            RemoveCommand = new DelegateCommand(Remove, canRemove);
           // SearchCommand = new DelegateCommand(Search, canSearch);
            LogoutCommand = new DelegateCommand(Logout, canLogout);
            ProductCommand = new DelegateCommand(ViewProduct, canExecute);
        }

        public void Add(object o)
        {
           Product s = new Product();
            s.ID = this.ID;
            s.Name = this.Name;
            s.Price = this.Price;
            s.Quantity = this.Quantity;

            ProductService.Addpro(s);
        }

        public void Remove(object o)
        {
           

            if(delID!=0)
            {
               ProductService.Remove(delID);
            }
        }


        public void Logout(object o)
        {
            SelectedViewModel = new HomeViewModel();
        }


        public bool canLogout(object o)
        {
            return true;
        }

       
      
        public bool canRemove(object o)
        {
            return true;

        }

        public bool canAdd(object o)
        {

            if (string.IsNullOrEmpty(ID.ToString()) ||
               string.IsNullOrEmpty(Name) ||
               string.IsNullOrEmpty(Price.ToString()) ||
               string.IsNullOrEmpty(Quantity.ToString()))
            {
                return false;
            }
            else
            {
                return true;
            }

        }


        public void ViewProduct(object o)
        {
            SelectedViewModel = new ProductsViewModel();
        }

        public bool canExecute(object o)
        {
            return true;
        }

        //public void Search(object o)
        //{
        //    if (ID != 0 && !(string.IsNullOrEmpty(ID.ToString())))
        //    {
        //        //Student s = studentService.GetStudentById(ID);
        //        //this.Name = s.Name;
        //       // this.Age = s.Age;
        //    }

        //}

        // public void Update(object o)
        //{
        //Student s = new Student();
        // s.ID = ID;
        // s.Name = Name;
        //s.Age = this.Age;
        //studentService.Update(s);

        // }
        //public bool canSearch(object o)
        //{
        //    if (ID != 0 && !(string.IsNullOrEmpty(ID.ToString())))
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}

       
    }
}

    
