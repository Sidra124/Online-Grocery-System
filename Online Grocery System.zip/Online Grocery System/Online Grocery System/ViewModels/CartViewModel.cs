﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Collections.ObjectModel;
using Online_Grocery_System.Models;
using Online_Grocery_System.Commands;

namespace Online_Grocery_System.ViewModels
{
    class CartViewModel : BaseViewModel
    { 

        public Cart SelectedCart { get; set; }
        public int CartID { get => cartID; set { cartID = value; OnPropertyChanged("ID"); } }
        public string CartName { get => cartName; set { cartName = value; OnPropertyChanged("Name"); } }
        public int CartQuantity { get => cartQuantity; set { cartQuantity = value; OnPropertyChanged("Quantity"); } }
        public float CartPrice { get => cartPrice; set { cartPrice = value; OnPropertyChanged("Price"); } }


        public ObservableCollection<Cart> Students { get; set; }
        public DelegateCommand CartCommand { get; set; }

        CartServiceModel CartService;
        private string cartName;
        private int cartQuantity;
        private int cartID;
        private float cartPrice;

        public CartViewModel()
        {
            CartServiceModel c = new CartServiceModel();

          //  Cart = CartServiceModel.GetAllStudents();
              CartCommand  = new DelegateCommand(AddINCart, canAddinCart);

        }

        public void AddINCart(object o)
        {
            Cart c = new Cart();
            c.CartID = this.CartID;
            c.CartName = this.CartName;
            c.CartQuantity = this.CartQuantity;
            c.CartPrice = this.CartPrice;
           // CartServiceModel.AddStudent(c);
        }


        public bool canAddinCart(object o)
        {

            if (string.IsNullOrEmpty(CartID.ToString()) ||
               string.IsNullOrEmpty(CartName) ||
               string.IsNullOrEmpty(CartQuantity.ToString()) ||
               string.IsNullOrEmpty(CartPrice.ToString()))
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        //public void Remove(object o)
        //{
        //    if (SelectedCart != null)
        //    {
        //        CartService.Remove(SelectedCart);
        //    }
        //}

        //public void Search(object o)
        //{
        //    if (ID != 0 && !(string.IsNullOrEmpty(ID.ToString())))
        //    {
        //        Student s = studentService.GetStudentById(ID);
        //        this.Name = s.Name;
        //        this.Age = s.Age;
        //    }

        //}

        //public void Update(object o)
        //{
        //    Student s = new Student();
        //    s.ID = ID;
        //    s.Name = Name;
        //    s.Age = this.Age;
        //    studentService.Update(s);

        //}
        //public bool canSearch(object o)
        //{
        //    if (ID != 0 && !(string.IsNullOrEmpty(ID.ToString())))
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}
        //public bool canRemove(object o)
        //{
        //    if (SelectedStudent != null)
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }

        //}

    }
}


